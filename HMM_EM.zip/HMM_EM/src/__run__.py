

import sys
sys.path.append(".")
sys.path.append("api")
sys.path.append("gui")

from gui.hand_reco_writer import HandRecoWriter

HandRecoWriter()